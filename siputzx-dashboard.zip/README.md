SIPUTZX Cyberpunk Neon Dashboard

Run:
1. npm install
2. npm run dev
3. Open http://localhost:5173

Notes:
- Project calls the provided public APIs directly from the browser.
- If you hit CORS issues, deploy from a domain allowed by the API or use a server-side proxy.
